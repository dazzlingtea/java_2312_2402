import java.util.*;

class Fan1 {
	final static int SLOW = 1;
	final static int MEDIUM = 2;
	final static int FAST = 3;
	
	int speed = SLOW;
	boolean on = false;
	double radius = 5;
	String color = "blue";
	

	
	int getSpeed() { return this.speed; }
	boolean getOn() { return this.on; }
	double getRadius() { return this.radius; }
	String getColor() { return this.color; }
	
	void setSpeed(int speed) {this.speed = speed;}
	void setOn(boolean on) {this.on = on;}
	void setRadius(double radius) {this.radius = radius;}
	void setColor(String color) {this.color = color;}
	
	Fan1() {
		this.speed = SLOW;
		this.on = false;
		this.radius = 5;
		this.color = "blue";
	}
	
//
	
}


public class Fan1App {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        Fan1 fan1 = new Fan1();
        for (int i = 0; i < n; i++) {
            String op = sc.next();
            String val = sc.next();
            if (op.compareTo("speed") == 0) {
                if (val.compareTo("SLOW") == 0) fan1.setSpeed(Fan1.SLOW);
                else if (val.compareTo("FAST") == 0) fan1.setSpeed(Fan1.FAST);
                else fan1.setSpeed(Fan1.MEDIUM);
            } else if (op.compareTo("radius") == 0) {
                fan1.setRadius(Double.parseDouble(val));
            } else if (op.compareTo("color") == 0) {
                fan1.setColor(val);
            } else if (op.compareTo("on") == 0) {
                if (val.compareTo("true") == 0) fan1.setOn(true);
                else fan1.setOn(false);
            }
        }
        System.out.println(fan1.toString());
    }
}