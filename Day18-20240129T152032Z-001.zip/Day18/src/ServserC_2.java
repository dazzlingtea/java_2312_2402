import java.net.*;
import java.io.*;
import java.util.*;

public class ServserC_2 {
	public static void main(String[] args) {
		ServerSocket listener = null;
		Socket socket = null;
		Scanner sc = new Scanner(System.in);
		BufferedReader in = null;
		BufferedWriter out = null;
		FileReader fin;
		
		try {
			listener = new ServerSocket(9998);
			System.out.println("���� ��� ��...");
			socket = listener.accept();
			System.out.println("����Ǿ����ϴ�.");
			
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			fin = new FileReader("C:\\Users\\Administrator\\Desktop\\scores.txt");
			int c;
			String s;
			while((c = fin.read()) != -1) {
				char ch = (char)c;
				s += ch;
			}
			String[] str = s.split(" ");
			HashMap<String, String> hm = new HashMap<String, String>();
			for(int i=0; i<str.length; i+=2) {
				hm.put(str[i], str[i+1]);
			}
			
			while(true) {

				String clientInput = in.readLine();
				if(clientInput.equals("bye")) {
					System.out.println("Ŭ���̾�Ʈ ������ ����");
					break;
				}
				else {
					
					
					out.write(formula + "\n");
					out.flush();
				}
				
				clientInput = in.readLine();
				System.out.println("Ŭ���̾�Ʈ: " + clientInput);

				out.flush();
			}
			
		} catch(IOException e) {
			System.out.println(e);
;
		} finally {
			try {
				sc.close();
				socket.close();
				listener.close();
			} catch(IOException e) {
				System.out.println("��� �� ���� �߻�");
			}
		}

	}

}
